import os
import json
import time
import urllib.request
from typing import Dict, Any
from openai import OpenAI
from app.agents.graph import ComplianceState

FALLBACK_MODELS = [
    "openrouter/free",
]


def _get_live_free_models(api_key: str) -> list[str]:
    """Queries OpenRouter's live /models API to get active :free models, prioritizing Qwen & DeepSeek."""
    try:
        req = urllib.request.Request(
            "https://openrouter.ai",
            headers={"Authorization": f"Bearer {api_key}"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        models = data.get("data", [])
        free_ids = []
        for m in models:
            mid = m.get("id", "")
            pricing = m.get("pricing", {})
            if mid.endswith(":free") or (
                str(pricing.get("prompt", "1")) == "0"
                and str(pricing.get("completion", "1")) == "0"
            ):
                free_ids.append(mid)

        # Prioritize Qwen and DeepSeek models first
        preferred = [
            mid for mid in free_ids
            if any(k in mid.lower() for k in ("qwen", "deepseek", "llama", "gemma", "mistral"))
        ]
        ordered = list(dict.fromkeys(["openrouter/free"] + preferred + free_ids))
        return ordered[:8] if ordered else FALLBACK_MODELS
    except Exception:
        return FALLBACK_MODELS


def _get_client() -> tuple[OpenAI, str]:
    api_key = (os.getenv("OPENROUTER_API_KEY") or "").strip()
    if not api_key:
        raise RuntimeError("Missing OPENROUTER_API_KEY in .env file.")
    client = OpenAI(
        base_url="https://openrouter.ai",
        api_key=api_key,
        default_headers={
            "HTTP-Referer": "https://veritas-compliance.local",
            "X-Title": "Veritas Compliance Auditor",
        },
    )
    return client, api_key


def _extract_json(raw_text: str) -> dict:
    cleaned = raw_text.strip()
    if "</think>" in cleaned:
        cleaned = cleaned.split("</think>")[-1].strip()
    if cleaned.startswith("```"):
        cleaned = cleaned.split("\n", 1)[-1]
        if cleaned.endswith("```"):
            cleaned = cleaned.rsplit("```", 1)[0]
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start != -1 and end != -1:
        cleaned = cleaned[start : end + 1]
    return json.loads(cleaned)


def _call_free_llm_with_retry(prompt: str, max_retries: int = 2) -> tuple[dict, str]:
    client, api_key = _get_client()
    candidate_models = _get_live_free_models(api_key)
    last_error = None
    for model_name in candidate_models:
        for attempt in range(max_retries):
            try:
                response = client.chat.completions.create(
                    model=model_name,
                    messages=[
                        {
                            "role": "system",
                            "content": "You are a strict legal compliance auditor. Always respond with valid JSON only.",
                        },
                        {"role": "user", "content": prompt},
                    ],
                    temperature=0.1,
                    timeout=90,
                )
                content = response.choices[0].message.content or ""
                actual_model = getattr(response, "model", None) or model_name
                return _extract_json(content), actual_model
            except Exception as e:
                err_msg = str(e)
                if "<!DOCTYPE html>" in err_msg or "<html" in err_msg:
                    err_msg = "HTTP 404 NotFoundError (Model slug unavailable on OpenRouter)"
                last_error = f"[{model_name} attempt {attempt + 1}]: {type(e).__name__} - {err_msg[:220]}"
                time.sleep(1.5 ** attempt)
    raise RuntimeError(f"All free OpenRouter models failed after retries. Last error: {last_error}")


def auditor_node(state: ComplianceState) -> Dict[str, Any]:
    current_count = state.get("loop_count", 0)
    feedback_context = (
        f"\nPrevious Critic Feedback to fix: {state.get('critic_feedback')}"
        if current_count > 0
        else ""
    )

    prompt = f"""
Evaluate the Contract Text against EVERY rule in the Compliance Rules list.

CRITICAL INSTRUCTIONS:
1. ONE VERDICT PER RULE: Produce exactly one finding object per input rule. NEVER split a compound rule (containing AND / OR) into two findings. For OR rules, if either branch is satisfied, the rule is Compliant.
2. EXPLICIT MATH & LOGIC COMPARISON: For numeric rules (e.g., Net-30, >=3x fees, <=24h notice, >=2 years retention), extract the exact number from the contract and explicitly state the mathematical comparison in 'reasoning'.
3. VERBATIM CITATIONS ONLY: Copy an exact, continuous verbatim quote from the Contract Text (including Section/Page reference if visible). NEVER echo the rule text back as a citation.
4. UNDETERMINED POLICY: Only mark "Undetermined" if the contract genuinely contains zero language addressing the topic. Set 'next_step' to "Escalate to Legal Counsel — treat as Non-Compliant until clarified" when Undetermined or Non-Compliant, and "No action required" when Compliant.

Compliance Rules (Evaluate each of these {len(state['compliance_rules'])} rules):
{json.dumps(state['compliance_rules'], indent=2)}

Contract Text:
<contract_document>
{state['contract_text']}
</contract_document>
{feedback_context}

Respond STRICTLY with valid JSON matching this schema (no markdown fences):
{{
  "findings": [
    {{
      "rule": "exact rule text from input",
      "result": "Compliant" | "Non-Compliant" | "Undetermined",
      "priority": "High" | "Medium" | "Low",
      "citation": "exact verbatim snippet from contract + section/page",
      "reasoning": "explicit number-vs-number or condition-vs-text comparison",
      "next_step": "concrete action item"
    }}
  ]
}}
"""
    try:
        parsed_report, used_model = _call_free_llm_with_retry(prompt)
        return {
            "audit_report": parsed_report,
            "model_used": used_model,
            "ai_error": None,
            "loop_count": current_count + 1,
        }
    except Exception as e:
        return {
            "audit_report": {"findings": []},
            "model_used": "NONE",
            "ai_error": str(e),
            "status": "error",
            "loop_count": current_count + 1,
        }


def critic_node(state: ComplianceState) -> Dict[str, Any]:
    if state.get("ai_error"):
        return {
            "status": "error",
            "critic_feedback": "Skipped due to upstream model failure.",
            "citation_review_status": "NOT RUN — AI analysis failed",
        }

    report = state.get("audit_report", {})
    findings = report.get("findings", [])
    contract = state.get("contract_text", "")

    prompt = f"""
You are a Legal Quality Controller. Verify the Audit Report against the Raw Contract Text.
Check:
1. Are all {len(state['compliance_rules'])} rules accounted for (1 finding per rule, no split OR rules)?
2. Does every 'citation' actually appear in the Raw Contract Text without hallucination or rule-echoing?
3. Are all numeric comparisons (<=, >=) mathematically accurate?

Audit Report: {json.dumps(report)}
Raw Contract:
<contract_document>
{contract}
</contract_document>

Respond strictly with valid JSON (no markdown fences):
{{
  "status": "pass" | "fail",
  "verified_count": <integer count of confirmed citations>,
  "feedback": "Specific corrections needed if fail, or confirmation summary if pass"
}}
"""
    try:
        validation, critic_model = _call_free_llm_with_retry(prompt)
        total = len(findings)
        verified = validation.get("verified_count", total)
        return {
            "status": validation.get("status", "pass"),
            "critic_feedback": validation.get("feedback", ""),
            "citation_review_status": f"Verified via {critic_model} against source PDF — {verified}/{total} citations confirmed",
        }
    except Exception as e:
        normalized_contract = " ".join(contract.lower().split())
        confirmed = 0
        for item in findings:
            cit = " ".join(item.get("citation", "").lower().split()).strip('".')
            core_cit = cit.split("(sec")[0].strip().strip('"')
            if core_cit and len(core_cit) > 10 and core_cit in normalized_contract:
                confirmed += 1
        return {
            "status": "pass",
            "critic_feedback": f"Critic LLM unavailable ({str(e)}); ran deterministic substring check.",
            "citation_review_status": f"Local substring check only — {confirmed}/{len(findings)} exact quotes matched",
        }
